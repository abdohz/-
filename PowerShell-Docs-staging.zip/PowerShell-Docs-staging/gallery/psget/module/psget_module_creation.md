---
ms.date:  2017-06-12
contributor:  manikb
ms.topic:  reference
keywords:  gallery,powershell,cmdlet,psget
title:  psget_module_creation
---

## When to include a project site, license URL, custom icon?


## What is minimum PowerShell version?

