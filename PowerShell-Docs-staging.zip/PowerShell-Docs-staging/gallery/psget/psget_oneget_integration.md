---
ms.date:  2017-06-12
contributor:  manikb
ms.topic:  reference
keywords:  gallery,powershell,cmdlet,psget
title:  psget_oneget_integration
---

## Architecture of PackageManagement and its relationship with PowerShellGet module.

## How to use PackageManagement cmdlets for discovering, installing, updating and inventory of scripts and modules using PowerShellGet provider.

## PakageManagement Commands

