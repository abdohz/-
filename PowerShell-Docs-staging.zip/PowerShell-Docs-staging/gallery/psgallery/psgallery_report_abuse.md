---
ms.date:  2017-06-12
contributor:  JKeithB
ms.topic:  conceptual
keywords:  gallery,powershell,cmdlet,psgallery
title:  psgallery_report_abuse
---

# Report Abuse

If you find a item that is in violation of any of these items, click the **Report Abuse** link on the item details page and submit a report.

