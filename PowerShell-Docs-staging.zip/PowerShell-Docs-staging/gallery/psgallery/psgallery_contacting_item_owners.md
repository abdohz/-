---
ms.date:  2017-06-12
contributor:  JKeithB
ms.topic:  conceptual
keywords:  gallery,powershell,cmdlet,psgallery
title:  psgallery_contacting_item_owners
---

# Contacting Item Owners

To contact owner of a particular item, navigate to the item detail page.
There is a contact Owners link in the left menu bar.
Clicking on the link will take you to a new page.
You can send a message from here.

