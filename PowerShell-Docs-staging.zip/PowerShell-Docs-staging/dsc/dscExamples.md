---
ms.date:  2017-06-12
author:  eslesar
ms.topic:  conceptual
keywords:  dsc,powershell,configuration,setup
title:  DSC Examples
---

# DSC examples

This section contains DSC examples:

- [Building a CI-CD pipeline with DSC, Pester, and Visual Studio Team Services](dscCiCd.md)
- [Separating configuration and environment data](separatingEnvData.md)

