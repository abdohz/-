# Desired State Configuration Roadmap

| Release Name | Planned Features | Alpha | Beta | RTM |
| ---- | -------- | :-------: | :-------:| :-----: |
| Downloadable package | TBD | TBD | TBD | TBD |
| TBD | TBD | TBD | TBD | TBD |

*Note: This table is currently just a placeholder. We will be updating it in the coming months and will keep it up to date as we progress with our plans.* 