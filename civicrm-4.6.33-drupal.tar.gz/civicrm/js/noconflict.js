if (!window.CRM) window.CRM = {};
window.cj = CRM.$ = jQuery.noConflict(true);
CRM._ = _.noConflict();
